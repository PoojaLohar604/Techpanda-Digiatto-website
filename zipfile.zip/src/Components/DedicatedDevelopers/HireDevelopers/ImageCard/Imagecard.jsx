import React from 'react';
import './Imagecard.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import pngwing1 from '../../../../Assets/pngwing 1.png';
import hireimage from '../../../../Assets/hireimage.png'
import Hirecard from '../../HireCard/Hirecard';

const Imagecard = () => {
  return (
    <div className='imagecard-content'>
      <Row>
        <Col lg={8} md={8} sm={6}>
        <div className='hire-image'>
            <img src={hireimage}/>
        </div>
        </Col>
        <Col lg={4} md={4} sm={6}>
        <div className="hire-card-center">
                    <Hirecard  heading="Hire PHP Developer" image={pngwing1}/>
        </div>
        </Col>
      </Row>
    </div>
  )
}

export default Imagecard